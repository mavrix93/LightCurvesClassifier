import logging

logging.basicConfig(level=logging.INFO)
logging.debug("Logging configured")
